package com.DavidMuheri.KadaiDen.Model;

/**
 * Created by MacBookPro on 10/12/17.
 */

public class PenjualanModel {
    private String no_faktur;

    public String getNo_faktur() {
        return no_faktur;
    }

    public void setNo_faktur(String no_faktur) {
        this.no_faktur = no_faktur;
    }


}
