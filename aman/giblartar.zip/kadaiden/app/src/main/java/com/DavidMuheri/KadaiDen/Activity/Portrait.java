package com.DavidMuheri.KadaiDen.Activity;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Portrait extends CaptureActivity {
}
